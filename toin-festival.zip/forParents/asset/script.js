// ========================================

$(".accordion").click(function(){
  $(this).toggleClass("active");
})